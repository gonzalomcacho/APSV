package es.upm.dit.apsv.traceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
@SpringBootApplication
class TraceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
