package es.upm.dit.apsv.transportationorderserver;

import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootTest
@SpringBootApplication
class TransportationOrderServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
